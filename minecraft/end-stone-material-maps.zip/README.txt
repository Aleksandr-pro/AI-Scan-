Estimated material maps from a single image, not measured geometry.
Albedo is used by the classic pack. Normal and MER are used only by the optional PBR overlay.
Height and AO are reference maps; neither creates real geometry or works in Classic.
Do not specify normal and heightmap together in a Bedrock texture set.
